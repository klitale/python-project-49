### Hexlet tests and linter status:
[![Actions Status](https://github.com/klitale/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/klitale/python-project-49/actions)

### Maintainability Badge:
<a href="https://codeclimate.com/github/klitale/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c1c2f2d4c693a0b61a96/maintainability" /></a>

### Asciinema brain-even:
[![asciicast](https://asciinema.org/a/zEfNFwSIHFYCvUBV00fxKPga9.svg)](https://asciinema.org/a/zEfNFwSIHFYCvUBV00fxKPga9)

### Asciinema brain-calc:
[![asciicast](https://asciinema.org/a/600880.svg)](https://asciinema.org/a/600880))

### Asciinema brain-gcd:
[![asciicast](https://asciinema.org/a/600881.svg)](https://asciinema.org/a/600881)
